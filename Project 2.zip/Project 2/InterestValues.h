#pragma once
#ifndef INTEREST_VALUES
#define INTEREST_VALUES

using namespace std;

class InterestValues {

public:

	InterestValues();

	void SetAmount(double amount);
	void SetDeposit(double deposit);
	void SetInterest(double interest);
	void SetYear(int year);

	int interestWithoutDeposit() {
		int i;
		double earnedInterest;
		//Balance and Interest w/out Deposits Table
		cout << "    Balance and Interest Without Additional Monthly Deposits    " << endl;
		for (i = 0; i < 64; ++i) {
			cout << "-";
		}
		cout << endl;
		cout << "  Year        Year End Balance     Year End Earned Interest  " << endl;

		//Earned interest calculations         
		for (i = 1; i < (year + 1); ++i) {
			earnedInterest = (interest / 100) * amount;
			amount += earnedInterest;
			cout << "    " << i << "              $" << amount << "                $" << earnedInterest << endl;
		}
		cout << endl;

		return 0;
	}

	int interestWithDeposits() {
		int i;
		int j;
		double monthlyInterest;

		//Balance and Interest With Deposits Table
		cout << "    Balance and Interest With Additional Monthly Deposits    " << endl;
		for (i = 0; i < 61; ++i) {
			cout << "-";
		}
		cout << endl;
		cout << "  Year        Year End Balance     Year End Earned Interest  " << endl;

		//Earned interest calculations with deposit
		for (i = 1; i < (year + 1); ++i) {
			double depositInterest = 0.0;
			for (j = 0; j < 12; ++j) {
				amount += deposit;
				monthlyInterest = amount * ((interest / 100) / 12);

				depositInterest += monthlyInterest;
				amount = monthlyInterest + amount;
			}
			cout << "    " << i << "              $" << amount << "                $" << depositInterest << endl;
		}

		return 0;
	}

private:
	double amount;
	double deposit;
	double interest;
	int year;

};

#endif