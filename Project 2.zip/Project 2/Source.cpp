#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

#include "InterestValues.h"

int displayMainMenu(double amount, double deposit, double interest, int year) {
	int i;
	for (i = 0; i < 34; ++i) {  //Top Line
		cout << "*";
	}

	cout << endl;

	for (i = 0; i < 11; ++i) {  //Bottom Line
		cout << "*";
	}

	cout << " Data Input ";

	for (i = 0; i < 11; ++i) {
		cout << "*";
	}

	cout << endl;

	//User info
	cout << "Initial Investment Amount: $" << amount << endl;
	cout << "Monthly Deposit: $" << deposit << endl;
	cout << "Annual Interest: " << interest << "%" << endl;
	cout << "Number of years: " << year << endl;

	return 0;
}

int main() {                                    
												                                       
	double initialAmount = 0.0;
	double monthlyDeposit = 0.0;
	double annualInterest = 0.0;
	int numYears = 0;
	char userInput;

	InterestValues calculateNums;
	
	cout << fixed << setprecision(2);   //Make doubles two decimal places

	//Main menu
	displayMainMenu(initialAmount, monthlyDeposit, annualInterest, numYears);

	//Ask user input
	cout << "Please enter values." << endl;
	
	cin >> initialAmount;  
	cin >> monthlyDeposit;
	cin >> annualInterest;
	cin >> numYears;	

	//Main menu with values
	displayMainMenu(initialAmount, monthlyDeposit, annualInterest, numYears);

 	
	cout << "Please press any key to continue . . . ";
	cin >> userInput;
	cout << endl;

	//Set user input values
	calculateNums.SetAmount(initialAmount);
	calculateNums.SetDeposit(monthlyDeposit);
	calculateNums.SetInterest(annualInterest);
	calculateNums.SetYear(numYears);


	calculateNums.interestWithoutDeposit();
	calculateNums.interestWithDeposits();

	return 0;
}