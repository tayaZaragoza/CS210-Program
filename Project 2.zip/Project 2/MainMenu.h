#pragma once
class MainMenu {
	for (i = 0; i < 34; ++i) {
		cout << "*";
	}
};

