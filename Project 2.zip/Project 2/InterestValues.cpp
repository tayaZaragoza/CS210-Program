#include <iostream>
using namespace std;

#include "InterestValues.h"

InterestValues::InterestValues() {
	amount = 0;
	deposit = 0;
	interest = 0;
	year = 0;
}

void InterestValues::SetAmount(double userAmount) {
	amount = userAmount;
}

void InterestValues::SetDeposit(double userDeposit) {
	deposit = userDeposit;
}

void InterestValues::SetInterest(double userInterest) {
	interest = userInterest;
}

void InterestValues::SetYear(int userYear) {
	year = userYear;
}

